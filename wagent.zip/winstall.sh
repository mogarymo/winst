#!/bin/bash

export APP_USER=wagent
export DIST_DIR="/opt/waseel"

export APP_NAME="wagent"
export WAGENT="wagent.sh"
export WAGENTR="wagentr.sh"
export TAR_NAME="$APP_NAME.tar"
export WCTL="wctl.sh"
export WCHECK="wcheck.sh"
export WCHECK_LOG_FILE="wcheck.log"
export CONF_FILE="$APP_NAME.properties"
export JAR_FILE="$APP_NAME.jar"
export SET_ENV="wsetenv.sh"

export INST_REG="/etc/wagent/inst.reg"

function set_env()
  {
	# Please note that the log files is managed under the app proprties file
	# This log is the log directed from the command line.

	export INST_DIR="$DIST_DIR/$APP_NAME"

	export LOG_FILE="${APP_NAME}_error.log"
	export JAVA_HOME=$INST_DIR/jre
	export LOG_DIR=$INST_DIR/logs
	export BIN_DIR=$INST_DIR/bin
	export TMP_DIR=$INST_DIR/tmp
	export CONF_DIR=$INST_DIR/conf
	export JARS_DIR=$INST_DIR/jars
	export LIB_DIR=$BIN_DIR/lib
	export JAR_FILE_FPATH=$JARS_DIR/$JAR_FILE
	export APP_NAME_UC=${APP_NAME^^}
	export SET_ENV_FPATH=$LIB_DIR/$SET_ENV
	export WAGENT_FPATH=$LIB_DIR/$WAGENT
	export WAGENTR_FPATH=$LIB_DIR/$WAGENTR
	export WCTL_FPATH=$BIN_DIR/$WCTL

	export WCHECK_FPATH=$LIB_DIR/$WCHECK
	export WCHECK_LOG_FILE_FPATH="$LOG_DIR/$WCHECK_LOG_FILE"

	export SPRING_CONFIG_LOCATION=file://$CONF_DIR/$CONF_FILE
	export SPRING_CONFIG_LOC=$CONF_DIR/$CONF_FILE
  }

function reset_default_env()
  {
	export APP_USER=wagent
	export DIST_DIR="/opt/waseel"
	set_env
  }


PDELAY=1
function check_prereq()
  {
    echo "Checking the system..."
    echo -n "["
    for i in `seq  1 94`
      do
        #echo -en "\r\x1B[2K";
        echo -n ".";
        sleep 0.02;
      done;
    echo "]"
    echo "Checking the system is completed."

    CUSER=`whoami`
    if [ "$CUSER" != "root" ]; then
      echo
      echo -n "Running the script as [$CUSER]..."
      echo -e "\e[1;31m ERROR: This script should be run as [root] user \e[0m"
      exit
    fi

  }

function read_param()
  {
    NM=$1
    PR=$2

    VAR=""
    while [ -z $VAR ]
      do
  	echo
  	read -p " $NM - $PR > " VAR

	if [ -z $VAR ]; then
	  echo
	  echo -e "\e[1;31m     Please enter a valid value. Do not leave it blank.  \e[0m"
	else
	  return 
	fi
      done
  }

function read_param_default()
  {
    NM=$1
    PR=$2
    DF=$3

    echo
    echo -n -e " $NM - $PR [\e[1;34m$DF\e[0m] > "
    read VAL
    if [ -z $VAL ]; then
      VAL=$DF
    fi
  }


function create_app_user()
  {
    USER=$1

    echo -n -e "     Checking the uer [\e[1;33m$USER\e[0m] ... "
    sleep $PDELAY
    if id $USER 1>/dev/null 2>&1 ;then
      echo " User is already exist."
    else
      echo " User does not exist. It will be created..."
      sleep 1
      echo -n -e "     Creating [\e[1;33m$USER\e[0m] user ... "
      RES=`useradd -m $USER 2>&1`
      if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mUser [$USER] is created successfully.\e[0m"
      else
        echo -e " \e[1;31mUser [$USER] creation failed. : $RES \e[0m"
      fi
    fi   
    sleep $PDELAY
  }

function create_dist_dir()
  {
    DIR=$1

    echo -n -e "     Checking the directory [\e[1;33m$DIR\e[0m] ... "
    sleep $PDELAY
    if [ -e $DIR ] ;then
      echo " Directory is already exist."
    else
      echo " The directory does not exist. It will be created..."
      echo -n -e "     Creating [\e[1;33m$DIR\e[0m] directory ... "
      sleep $PDELAY
      RES=`mkdir -p $DIR 2>&1`
      if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mDirectory [$DIR] is created successfully.\e[0m"
      else
        echo -e " \e[1;31mDirectory [$DIR] creation failed. : $RES \e[0m"
	echo
	exit 1
      fi
    fi   
    sleep $PDELAY
  }

function check_inst_dir()
  {
    DIR=$1

    echo -n -e "     Checking the instllation directory [\e[1;33m$DIR\e[0m] ... "
    sleep $PDELAY
    if [ -e $DIR ] ;then
      echo " Directory is already exist."
      echo
      echo "     Please choose different directory or run the following command as root to remove the existing directory:"
      echo "     rm -fr $DIR"
      echo
      exit 1
    else
      echo " The directory does not exist. It will be created..."
    fi   
    sleep $PDELAY
  }

# This function is not being used now
function create_dir()
  {
    DIR=$1

    echo -n -e "     Creating [\e[1;32m$DIR\e[0m] directory ... "
    sleep 1
    RES=`mkdir -p $DIR 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mDirectory [$DIR] is created successfully.\e[0m"
    else
        echo -e " \e[1;31mDirectory [$DIR] creation failed. : $RES \e[0m"
	return 1
    fi
    sleep 1
  }

function expand_app_tar()
  {
    echo -n -e "     Extracting Agent files from [\e[1;33m$TAR_NAME\e[0m] tar file ... "
    sleep $PDELAY
    RES=`tar -xvf $TAR_NAME 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mFiles are extracted successfully.\e[0m"
    else
        echo -e " \e[1;31mFiles extraction failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function create_app_dirs()
  {
    echo -n -e "     Creating Agent files and directories [\e[1;33m$INST_DIR\e[0m] ... "
    sleep $PDELAY
    RES=`mv $APP_NAME $DIST_DIR 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mFiles and Directories are created successfully.\e[0m"
    else
        echo -e " \e[1;31mFiles and Directories creation failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function set_dir_ownership()
  {
    echo -n -e "     Setting the Agent Files and Directories ownership to [\e[1;33m$APP_USER\e[0m] Agent User... "
    sleep $PDELAY
    RES=`chown -R $APP_USER:root $INST_DIR 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mOwnership is set successfully.\e[0m"
    else
        echo -e " \e[1;31mOwnership setting failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function set_inst_dir_var()
  {
    echo -n -e "     Setting the Agent Instalaltion Directory Variable in [\e[1;33m$SET_ENV_FPATH\e[0m] to [\e[1;33m$INST_DIR\e[0m] ... "
    sleep $PDELAY
    RES=`sed -i "s:^\s*export\s*INST_DIR\s*=\s*.*$:export INST_DIR=$INST_DIR:" $SET_ENV_FPATH 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32m$SET_ENV is set successfully.\e[0m"
    else
        echo -e " \e[1;31m$SET_ENV setting failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function set_app_user_var()
  {
    echo -n -e "     Setting the Agent User Variable in [\e[1;33m$SET_ENV_FPATH\e[0m] to [\e[1;33m$APP_USER\e[0m] ... "
    sleep $PDELAY
    RES=`sed -i "s:^\s*export\s*APP_USER\s*=\s*.*$:export APP_USER=$APP_USER:" $SET_ENV_FPATH 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32m$SET_ENV is set successfully.\e[0m"
    else
        echo -e " \e[1;31m$SET_ENV setting failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function set_agent_name()
  {
    echo -n -e "     Setting the Agent Name [\e[1;33mwagent.name\e[0m] to [\e[1;33m$AGENT_NAME\e[0m] ... "
    sleep $PDELAY
    RES=`sed -i "s/^\s*wagent.name\s*=\s*.*$/wagent.name = $AGENT_NAME/" $SPRING_CONFIG_LOC 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mAgent Name is set successfully.\e[0m"
    else
        echo -e " \e[1;31mAgent Name setting failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function set_agent_code()
  {
    echo -n -e "     Setting the Agent Code [\e[1;33mwagent.code\e[0m] to [\e[1;33m$AGENT_CODE\e[0m] ... "
    sleep $PDELAY
    RES=`sed -i "s/^\s*wagent.code\s*=\s*.*$/wagent.name = $AGENT_CODE/" $SPRING_CONFIG_LOC 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mAgent Code is set successfully.\e[0m"
    else
        echo -e " \e[1;31mAgent Code setting failed. \e[0m"
        echo -e "     \e[1;31mERROR : $RES \e[0m"
	return 1
    fi
    sleep $PDELAY
  }

function delete_inst_dir()
  {
    DIR=$1

    echo -n -e "     Checking the installation directory [\e[1;33m$DIR\e[0m] ... "
    sleep $PDELAY
    if [ -d $DIR ] ;then
      echo " Directory is found and it will be deleted."
      sleep $PDELAY
      echo -n -e "     Deleting the installation directory [\e[1;33m$DIR\e[0m] ... "
      sleep $PDELAY
      RES=`rm -fr $DIR 2>&1`
      if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mDirectory [$DIR] is deleted successfully.\e[0m"
      else
        echo -e " \e[1;31mDirectory [$DIR] deletion failed. : $RES \e[0m"
	echo
	echo -e "     \e[1;31mERROR\e[0m : Agent removal failed. Existing."
	echo
	exit 1
      fi

    else
      echo " The directory does not exist. It will be skipped..."
    fi   
    sleep $PDELAY
  }

function delete_app_user()
  {
    USER=$1

    echo -n -e "     Checking the uer [\e[1;33m$USER\e[0m] ... "
    sleep $PDELAY
    if id $USER 1>/dev/null 2>&1 ;then
      echo " User is found and it will be deleted."
      sleep $PDELAY

      echo
      echo -n -e "     Delete the Agent User [\e[1;33m$USER\e[0m] \e[0;33my/n\e[0m [\e[1;32mn\e[0m] > " 
      read REP
      echo
      if [ "$REP" != "y" ] ;then
	  echo -e "     The Agent User will not be deleted."
	  return
      fi

      echo -n -e "     Deleting [\e[1;33m$USER\e[0m] user ... "
      RES=`userdel $USER 2>&1`
      if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mUser [$USER] is deleted successfully.\e[0m"
      else
        echo -e " \e[1;31mUser [$USER] deletion failed. : $RES \e[0m"
      fi

    else
      echo " User does not exist. It will be skipped..."
    fi   
    sleep $PDELAY
  }

function delete_inst_registry()
  {
    RFILE=$1

    echo -n -e "     Deleting the installation registry file [\e[1;33m$RFILE\e[0m] ... "
    sleep $PDELAY
    RES=`rm $RFILE 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mRegistry file [$RFILE] is deleted successfully.\e[0m"
    else
        echo -e " \e[1;31mRegistry file [$RFILE] deletion failed. : $RES \e[0m"
	echo
	echo -e "     \e[1;31mERROR\e[0m : Agent removal failed. Existing."
	echo
	exit 1
    fi
    sleep $PDELAY
  }

function stop_wagent()
  {
    echo -n -e "     Stopping the Agent ... "
    sleep $PDELAY

    RES=`$WCTL_FPATH stop 2>&1`
    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mAgent is stopped successfully or it is not running.\e[0m"
    else
        echo -e " \e[1;31mAgent stop failed. : $RES \e[0m"
    fi
    sleep $PDELAY
  }

function check_old_inst()
  {
    echo -n -e "     Checking for an old Agent installation ... "
    sleep $PDELAY
    if [ -f $INST_REG ] ;then
        echo -e " \e[1;31mOld installation is detected.\e[0m"

	echo
    	sleep $PDELAY

	while read l
   	  do
	    echo -e "         \e[1;33m $l \e[0m"

	    if grep "\s*inst.dir\s*=" <<< "$l" 2>&1 1>/dev/null; then
	      INST_DIR=`echo $l|sed "s/inst.dir\s*=\s*//"`
	    fi

	    if grep "\s*user\s*=" <<< "$l" 2>&1 1>/dev/null; then
	      APP_USER=`echo $l|sed "s/user\s*=\s*//"`
	    fi

	  done < $INST_REG

	DIST_DIR=$(dirname "$INST_DIR")

	echo
	CMSG="The installation is cancelled. Existing ... \e[1;32mThank you\e[0m."
  	echo -n -e "Do you want to remove the detected old installation \e[0;33my/n\e[0m [\e[1;32mn\e[0m] > " 
  	read REP
  	#echo -e "You have entered [\e[1;34m$REP\e[0m]..."
	if [ "$REP" = "y" ] ;then
	  echo -n -e "Are you sure \e[0;33my/n\e[0m [\e[1;32mn\e[0m] > "
  	  read REP
	  if [ "$REP" = "y" ] ;then
	    set_env
	    echo
	    stop_wagent
	    echo
	    delete_inst_dir $INST_DIR
	    echo
	    delete_app_user $APP_USER
	    echo
	    delete_inst_registry $INST_REG
	    echo
	    remove_crontab_task
	    echo
	    echo -e "    \e[1;35m The old Agent installation removal is completed. \e[0m"
	    echo
  	    echo -n -e "Do you want to continue to install a fresh Agent \e[0;33my/n\e[0m [\e[1;32mn\e[0m] > " 
  	    read REP
  	    if [ "$REP" != "y" ]; then
	      echo
	      echo -e "$CMSG"
	      echo
	      exit
  	    fi
	  else
	    echo
	    echo -e "$CMSG"
	    echo
	    exit
	  fi
	else
	  echo
	  echo -e "$CMSG"
	  echo
	  exit
	fi
	
	
    else
        echo -e " \e[1;32mNo old installation is detected. \e[0m"
	return 1
    fi

    sleep $PDELAY
  }

function create_inst_registry()
  {
    RFILE=$1

    echo -n -e "     Creating the installation registry file [\e[1;33m$RFILE\e[0m] ... "
    sleep $PDELAY
    RDIR=$(dirname "$RFILE")
    mkdir $RDIR 2>&1 1>/dev/null

    REG_DATE="inst.date = `date`"
    REG_INST_DIR="inst.dir  = $INST_DIR"
    REG_USER="user      = $APP_USER"
    RES=`cat <<EOT > $RFILE
$REG_DATE
$REG_INST_DIR
$REG_USER
EOT`

    if [ $? -eq 0 ] ;then
        echo -e " \e[1;32mRegistry file [$RFILE] is created successfully.\e[0m"
    else
        echo -e " \e[1;31mRegistry file [$RFILE] creation failed. : $RES \e[0m"
	echo
	echo -e "     \e[1;31mERROR\e[0m : Agent installation did not finish all the installation steps successfully. Existing."
	echo
	exit 1
    fi
    sleep $PDELAY
  }

function create_crontab_task()
  {
    TMPF="/tmp/wagent.crontab"
    CJOB="0 * * * * $WCHECK_FPATH 2>&1 >> $WCHECK_LOG_FILE_FPATH"
    RM_TMPF="rm $TMPF"

    echo -n -e "     Creating the crontab job to run the checking script [\e[1;33m$WCHECK_FPATH\e[0m] ... "
    sleep $PDELAY

    RES=`crontab -l > $TMPF 2>/dev/null`

    RES=`sed -i "/$WCHECK/d" $TMPF 2>&1`
    if [ $? -ne 0 ] ;then
        echo -e " \e[1;31mCreating the crontab job failed. : $RES \e[0m"
        sleep $PDELAY
	$RM_TMPF 2>&1 1>/dev/null
	return 1
    fi

    RES=`echo "$CJOB" >> $TMPF`
    if [ $? -ne 0 ] ;then
        echo -e " \e[1;31mCreating the crontab job failed. : $RES \e[0m"
        sleep $PDELAY
        $RM_TMPF 2>&1 1>/dev/null
	return 1
    fi

    RES=`crontab $TMPF`
    if [ $? -ne 0 ] ;then
        echo -e " \e[1;31mCreating the crontab job failed. : $RES \e[0m"
        sleep $PDELAY
        $RM_TMPF 2>&1 1>/dev/null
	return 1
    fi

    echo -e " \e[1;32mCrontab job is created successfully.\e[0m"
    sleep $PDELAY
    $RM_TMPF 2>&1 1>/dev/null
  }

function remove_crontab_task()
  {
    TMPF="/tmp/wagent.crontab"
    RM_TMPF="rm $TMPF"

    echo -n -e "     Removing the crontab job for the checking script [\e[1;33m$WCHECK\e[0m] ... "
    sleep $PDELAY

    RES=`crontab -l > $TMPF 2>/dev/null`
    if [ $? -ne 0 ] ;then
        echo -e " \e[1;31mRemoving the crontab job failed. : $RES \e[0m"
        sleep $PDELAY
	return 1
    fi

    RES=`sed -i "/$WCHECK/d" $TMPF 2>&1`
    if [ $? -ne 0 ] ;then
        echo -e " \e[1;31mRemoving the crontab job failed. : $RES \e[0m"
        sleep $PDELAY
	$RM_TMPF 2>&1 1>/dev/null
	return 1
    fi

    RES=`crontab $TMPF`
    if [ $? -ne 0 ] ;then
        echo -e " \e[1;31m31mRemoving the crontab job failed. : $RES \e[0m"
        sleep $PDELAY
	$RM_TMPF 2>&1 1>/dev/null
	return 1
    fi

    echo -e " \e[1;32mCrontab job is removed successfully.\e[0m"
    sleep $PDELAY
    $RM_TMPF 2>&1 1>/dev/null
  }

######################################## Main Program ################################################

echo
echo
echo "################################################################################################"
echo "#                                                                                              #"
echo "#                            Waseel ASP. Waseele Agent                                         #"
echo "#                                                                                              #"
echo "#  This is the installation of Waseele Agent (WAGENT). Please follow the instruction           #"
echo "#  carefully to complete the installation sccuessfully.                                        #"
echo "#                                                                                              #"
echo "#  We highly recommend that you leave the default values as is unless you have to chaneg them. #"
echo "#                                                                                              #"
echo "################################################################################################"
echo
check_prereq
echo
check_old_inst

echo

START_INSTALL="n"

while [ "$START_INSTALL" != "y" ]
do
  reset_default_env
  echo
  echo "Please enter the following values or just press Enter to accept the default value:"

  read_param_default "1" "Agent User. The user will be created if it does not exist" "$APP_USER"
  U_APP_USER=$VAL
  
  read_param_default "2" "Installation/Distination Directory" "$DIST_DIR"
  U_DIST_DIR=$VAL

  read_param "3" "Agent Name / Provider Code"
  AGENT_NAME=$VAR

  read_param "4" "Agent Code / Provider CCHI Number"
  AGENT_CODE=$VAR


  echo
  echo "You have entered the following:"
  echo
  echo -e " 1 - Agent User                      :\e[1;32m $U_APP_USER \e[0m"
  echo -e " 2 - Installation Directory          :\e[1;32m $U_DIST_DIR \e[0m"
  echo -e " 3 - Agent Name / Provider Code      :\e[1;32m $AGENT_NAME \e[0m"
  echo -e " 4 - Agent Code / Provider CCHI Num. :\e[1;32m $AGENT_CODE \e[0m"
  echo
  echo -n -e "Please confirm the installation parameters by entring \e[0;33my/n\e[0m or \e[0;33mq\e[0m to Quit [\e[1;32my\e[0m] > " 
  read START_INSTALL
  if [ -z $START_INSTALL ]; then
    START_INSTALL="y"
  fi
  echo "You have entered [$START_INSTALL]..."
  if [ $START_INSTALL = "q" ]; then
    exit
  fi

done

DIST_DIR=$U_DIST_DIR
APP_USER=$U_APP_USER
set_env

echo
create_app_user $APP_USER
echo
check_inst_dir $INST_DIR
echo
create_dist_dir $DIST_DIR
echo
expand_app_tar 
echo
create_app_dirs 
echo
set_inst_dir_var
echo
set_app_user_var
echo
set_agent_name
echo
set_agent_code
echo
set_dir_ownership
echo
create_inst_registry $INST_REG
echo
create_crontab_task
echo
sleep $PDELAY
echo -e "\e[1;35mThe Agent installation is completed.\e[0m To start the Agent, please do the following:"
sleep $PDELAY
echo
echo -e " 1 - Login or switch to [\e[1;33m $APP_USER \e[0m] user"
sleep $PDELAY
echo -e " 2 - Run the following command:\e[1;33m $WCTL_FPATH start \e[0m"
sleep $PDELAY
echo
echo -e "     The installation process is finished. Existing ... \e[1;32mThank you\e[0m."
echo
